#pragma once
#include <SFML/Window.hpp>

void processEvents(sf::Window& window);
