#pragma once
#include <SFML/System/Vector2.hpp>


struct Star
{
    sf::Vector2f position;
    float z = 1.0f;
};
