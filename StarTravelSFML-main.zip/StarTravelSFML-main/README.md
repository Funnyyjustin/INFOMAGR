# StarTravel

Minimalist SFML project.

[SFML documentation](https://www.sfml-dev.org/)

# Compilation

To compile, the following commands can be used
```bash
mkdir build
cd build
cmake ..
cmake --build .
```
